"""CustomTkinter user interface."""
