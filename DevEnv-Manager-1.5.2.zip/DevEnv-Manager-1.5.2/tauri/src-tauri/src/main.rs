#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    dailytools_tauri_lib::run();
}
